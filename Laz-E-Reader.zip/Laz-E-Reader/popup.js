//search bar
function SearchFunction(e)
{
	var searchTerm = document.getElementById('searchTerm').value;	
	if(searchTerm == "")
		alert("Enter search term!")
	else
	{
		chrome.tabs.update({url: "http://www.google.com/search?q="+encodeURIComponent(searchTerm)+"&btnI" });
		window.close(); // Note: window.close(), not this.close()			
	}
}
//This handles the search button (GO!)
document.addEventListener('DOMContentLoaded',function() {
	document.getElementById('GO').addEventListener('click', SearchFunction);
});

//This handles the CNN button
function cnnHandler(e) {
    chrome.tabs.update({url: "http://cnn.com"});
    window.close(); // Note: window.close(), not this.close()
}
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('cnnClick').addEventListener('click', cnnHandler);
});
//This handles the reuters button
function reutersHandler(e) {
    chrome.tabs.update({url: "http://reuters.com"});
    window.close(); // Note: window.close(), not this.close()
}
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('reutersClick').addEventListener('click', reutersHandler);
});
//This handles the medium button
function mediumHandler(e) {
    chrome.tabs.update({url: "http://medium.com"});
    window.close(); // Note: window.close(), not this.close()
}
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('mediumClick').addEventListener('click', mediumHandler);
});

//Stuff for read button

function strip(html)
{
   var tmp = document.createElement("DIV");
   tmp.innerHTML = html;
   return tmp.textContent || tmp.innerText || "";
}

function getResponse(request)
{
		if (request.readyState == 4) 
		{
		response = JSON.parse(request.responseText);
		var text = strip(response.content);
		var title = strip(response.title);
		//document.write(text);							//debug
		responsiveVoice.speak("title. " + title,"US English Female");
		responsiveVoice.speak("story. " + text,"US English Female");
		}

}
function readCurrentPage(e) {

    chrome.tabs.query({'active': true, 'windowId': chrome.windows.WINDOW_ID_CURRENT},
       function(tabs){

            var url = tabs[0].url;
			var path="https://mercury.postlight.com/parser?url="+encodeURIComponent(url);
            var request = new XMLHttpRequest();
            request.open("GET", path, false);
            request.setRequestHeader("x-api-key", "NUpVqMoObH2wjbEmHXSjJy51JPW8ZGyFTwkG1FGm");
            request.setRequestHeader("Content-Type", "application/json");
			request.send(null);
			request.onreadystatechange = getResponse(request);
       }
    );

}
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('readClick').addEventListener('click', readCurrentPage);
});

document.addEventListener('DOMContentLoaded',function() {
	document.getElementById('GO').addEventListener('click', SearchFunction);
});

//This handles the stop button
function stopReading(e) {
    responsiveVoice.cancel();
}
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('stahp').addEventListener('click', stopReading);
});

/*//This handles the pause button
function pauseReading(e) {
   if(responsiveVoice.isPlaying())
    responsiveVoice.pause();
}
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('pauseButton').addEventListener('click', pauseReading);
});

//This handles the resume button
function resumeReading(e) {
    responsiveVoice.resume();
}
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('resume').addEventListener('click', resumeReading);
});
*/

